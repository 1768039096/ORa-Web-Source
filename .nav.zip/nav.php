<!doctype html>
<html>
<head>
 <base target="iframe_a"/>
 <meta charset="utf-8" />
<link rel='stylesheet' type="text/css" href=".nav/css/nav.css" />
<script  type="text/javascript" src=".nav/javascript/baidu.js"></script>
<script  type="text/javascript" src=".nav/javascript/sethight.js"></script>
<title ><?php 
    readfile (".nav/title");
?>
 </title>
<meta name="keywords" content="
<?php 
    readfile (".nav/keywords");
?>
" />
<meta name="description" content=" 
<?php 
    readfile (".nav/description");
?>
" />
</head>
<body>
<div class='outiframe'>
<h1>
<?php 
    readfile (".nav/title");
?> </h1>

<!--菜单 | 内联框架-->

<nav id='nav' class='nav'>
<?php 
    readfile (".nav/siteurl");
?>
 <!--
<a href="sitemap.php" target="iframe_a"> 网站地图</a>
  <a href='yunpan' target="iframe_a" >公共网盘 </a> 
-->
</nav>
</div><!--end out iframe-->
<!--<iframe src="" name="iframe_a" width="95%" height="100%"></iframe>-->
<iframe name="iframe_a" src="sitemap.php" frameborder="0" scrolling="yes" id="external-frame" onload="setIframeHeight(this)" width='95%'></iframe>


<!-- 尝试屏蔽被嵌入的非页面元素,包括JavaScript-->
<iframe sandbox='' style='display:none;' >
 <!-- 
</body>
</html>
