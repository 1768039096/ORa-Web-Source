//<script>
//ora.eu5.org 
//https://tongji.baidu.com/web/welcome/ico?s=70c782954eae2596876074c15629b443
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?70c782954eae2596876074c15629b443";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
//</script>
