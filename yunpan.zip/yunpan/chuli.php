<!DOCTYPE html >

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<?php

echo "

 <hr>  <span><a href=' upload.php'>返回上传</a><span>

<hr> 

<span><a href=' upload.php'>查看已有文件</a><span>

<hr> 

<span><a href=' sitemap.php'>网站地图</a><span>

<hr>  " ;

function jianCuo() {
if ($_FILES["file"]["error"] > 0)
  {
  echo "Error: " . $_FILES["file"]["error"] . "<br />";exit (0);
 
  }
elseif( strlen($_FILES["file"]["name"]) == 0 ) {
//文件名为空，即未输入，
echo "no input.<br><br/>"; exit (0);
}
elseif (file_exists("upload/" . $_FILES["file"]["name"] . ".upload"))
      {
      echo $_FILES["file"]["name"] . " already exists. "; exit (0);
 }
}

//kong ge chu li
function emptyReplace($str) {  //替换空格到$newChar，
$newChar = '-';	 
$str = str_replace('　', ' ', $str); //替换全角空格为半角
//$str = str_replace(' ', ' ', $str); //替换连续的空格为一个
$str = trim ($str);//去除一个字符串两端空格
$str = preg_replace("/[\s]+/is"," ",$str); //将多余的空格用一个空格替换 
$noe = false; //是否遇到不是空格的字符
for ($i=0 ; $i<strlen($str); $i++) { //遍历整个字符串
	if($noe && $str[$i]==' ')  //如果当前这个空格之前出现了不是空格的字符
		$str[$i] = $newChar; 
	elseif($str[$i]!=' ')  //当前这个字符不是空格，定义下 $noe 变量
		$noe=true;
}
return $str;
} 
  
function saveFile  () {
      move_uploaded_file($_FILES["file"]["tmp_name"], "upload/" . $_FILES["file"]["name"]);

      rename("upload/" . $_FILES["file"]["name"],"upload/" . $_FILES["file"]["name"] . ".upload");

      echo "Stored in: " . "upload/" . $_FILES["file"]["name"] . ".upload";
      echo "<br><a href='" . "upload/" . $_FILES["file"]["name"] . ".upload" . "'>  查看 </a>";
}


function saveFileuploadTime  () {

$recordFile="uploadRecord.txt";
$fileurl="upload/" . $_FILES["file"]["name"] . ".upload";
$filename=$_FILES["file"]["name"] . ".upload";
$filetime=date('Y-m-d,H:i:s,a');
$filesize=$_FILES["file"]["size"] / 1024 /1024 ;
$txt="

<tr> <td align=left><a href=$fileurl>  $filename  </a></td>

<td align=left>$filetime</td><td align=left>  $filesize Mb </td></tr> 
";

$myfile=fopen($recordFile, "a");

fwrite($myfile, $txt);

fclose($myfile);

}



//###################start#########################
  // jian cuo.
  jianCuo ();
  //zhong wen zhuan huan.
	 $_FILES["file"]["name"] = iconv("UTF-8","gb2312",$_FILES["file"]["name"]);
    $_FILES["file"]["name"] = iconv( "GBK","UTF-8",$_FILES["file"]["name"]);
 //kong ge chu li
  $_FILES["file"]["name"] = emptyReplace($_FILES["file"]["name"]);
  //bao cun wen jian ;
  saveFile  ();
 //bao cun ji lu;
  saveFileuploadTime  ();
//####################end########################
?>

<!-- 尝试屏蔽被嵌入的非页面元素,包括JavaScript-->
<iframe sandbox='' style='display:none;' >
 <!-- 
</body>
</html>

