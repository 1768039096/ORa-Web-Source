<!doctype html>
<html>
<head>
<title ><?php 
    readfile (".etc/title");
?>
 </title>
<meta charset="utf-8" />
<meta name="keywords" content="
<?php 
    readfile (".etc/keywords");
?>
" />
<meta name="description" content=" 
<?php 
    readfile (".etc/description");
?>
" />
<?php 
//javascript
    readfile (".etc/linkjs");
?>
</head>

<body>
<h1>
<?php 
    readfile (".etc/title");
?> </h1>
<h2>上传文件</h2>

<form action="chuli.php" method="post" enctype="multipart/form-data">

选择文件<input  type="file" name="file" /><input type="submit"  value="&#19978;&#20256;" />

</form>
<hr> 
<!--<span><a href="uploadtime.php">查看已有文件</a><span> -->
<hr> 
<span><a href="sitemap.php">网站地图</a><span>
<hr> 

<div>
<?php 
    echo "<div style='color:red'>注意：</div>";
    readfile (".etc/notice");
?> 
 </div>
<br> 
<span>合作交流=><a href='mailto:ora2017@qq.com'>ORA2017@qq.com</a> </span>
<hr><hr/>
<h2> 历史文件：</h2>

  
<?php
$openFileName = "uploadRecord.txt";
$tableHead = '
<table   align=left style="word-break:break-all;word-wrap:break-word;line-height:200% ;background-color:gainsboro; " >
   <tr> <th width=43%><a href=" ">Name</a></th>  <th width=33%><a href=" ">upload time</a></th><th width=23%><a href=" ">Size</a></th></tr>
   <tr><th colspan="4"><hr></th></tr>
';
echo $tableHead ;
$file = fopen("$openFileName", "r") or exit("无法打开文件!");
// 读取文件每一行，直到文件结尾
while(!feof($file))
{
    echo fgets($file) ;
}
fclose($file);
?>  
<!-- 尝试屏蔽被嵌入的非页面元素,包括JavaScript-->
<iframe sandbox='' style='display:none;' >
 <!-- 
</body>

</html> 
 
