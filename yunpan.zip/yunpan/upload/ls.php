<!doctype html>
<!-- #####################################################-->
<form method="post" action="<?php print $_SERVER['PHP_SELF']?>">
<p>
password: <input type="text" name="passwd" /><input type="submit" name="提交" />
</p>
</form>
 

<?php  
// list file;need password to login .
echo "<a href='../'> ../ </a>";
echo "<h1>文件表列：</h1>";
$dir = ".";  
$permession="false"; //false or true ;
$passwordseted="ora2017";
//###########################################
//#
function ls($dir) {
if (is_dir($dir)) {  
   if ($dh = opendir($dir)) {  

       while (($file = readdir($dh)) !== false) {  
       if ($file!="." && $file!=".." && substr(strrchr($file, '.'), 1)!="php" && substr(strrchr($file, '.'), 1)!="html" && substr(strrchr($file, '.'), 1)!="htm" ) {  
       echo "<a href='$file'>".$file."</a><br>";  
       }  
       }  
       closedir($dh);  
   }  
}  
}//end function ls();
//#
function verifyPassword ($i,$j) {
//echo strcmp("Ha","Ha"); //字符串相同返回0；
//if(! strcmp("Ha","Ha") )  {echo "yes";}
  if (! strcmp( $i,$j)){
       //echo ("yes");
        return $permession="true";
    }
    else {
        return $permession="false";
    }
}
//########################################
//# 开始执行。
//数据不为空,验证数据，根据验证结果选择是否输出文件列表。
if ( ! empty( $_POST['passwd'] ) ) {
   // print "last passwd: ".$_POST['passwd'];
   if ( verifyPassword($_POST['passwd'],$passwordseted) == "true" ) {
     echo "passwd true.passwd is " . $_POST['passwd'] . "<br><br/>"; 
     ls($dir);
     }
     else {echo "passwd error.";}
   
}
else {echo "no input.";}
?>

