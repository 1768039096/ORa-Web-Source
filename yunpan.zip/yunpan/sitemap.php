<!doctype html>
<html>
<head>
<title >
<?php 
    readfile (".etc/title");
?>
 </title>
<meta charset="utf-8" />
<meta name="keywords" content="
<?php 
    readfile (".etc/keywords");
?>
" />
<meta name="description" content=" 
<?php 
    readfile (".etc/description");
?>
" />
<?php 
//javascript
    readfile (".etc/linkjs");
?>
</head>

<body>
<h1>
<?php 
    readfile (".etc/title");
?> </h1>
<h2>网站地图</h2>
	<span > </span>
	<ul>
    <li> <a href="upload.php" > 上传文件</a>  </li>
    <li> <a href="upload.php" > 查看/下载文件</a>  </li>
   
	</ul>
 
<!-- 尝试屏蔽被嵌入的非页面元素,包括JavaScript-->
<iframe sandbox='' style='display:none;' >
 <!-- 
</body>

</html>
