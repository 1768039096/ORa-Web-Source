<!doctype html>
<html>
<head>
<title ><?php 
    readfile (".sitemap/title");
?>
 </title>
<meta charset="utf-8" />
<meta name="keywords" content="
<?php 
    readfile (".sitemap/keywords");
?>
" />
<meta name="description" content=" 
<?php 
    readfile (".sitemap/description");
?>
" />
<link rel='stylesheet' type="text/css" href=".sitemap/css/sitemap.css" />
<script  type="text/javascript" src=".sitemap/javascript/baidu.js"></script>

</head>
<body>

<hr />
<!--<h1>
<?php 
    readfile (".sitemap/title");
?> </h1> -->
<h2>网站地图</h2>
<!--内链-->
<?php
//
echo "<ul class='left'>";
$openFileName = ".sitemap/mylink";
$file = fopen("$openFileName", "r") or exit("无法打开文件!");
// 读取文件每一行，直到文件结尾
while(!feof($file))
{
    printf ( fgets($file) ) ;
}
fclose($file);
echo "</ul>";
?>   
<!--外链-->
<?php
//
echo "<ul class='right'>";
$openFileName = ".sitemap/friendlink";
$file = fopen("$openFileName", "r") or exit("");
// 读取文件每一行，直到文件结尾
while(!feof($file))
{
    printf ( fgets($file) ) ;
}
fclose($file);
echo "</ul>";
?>   

<!--
	<ul>
    <li> <a href="yunpan/" > 简单免登陆云盘</a>  </li>
    <li><a href="mailto:ora2017@qq.com"   >管理员邮箱： ora2017@qq.com</a></li>
	</ul>
 -->


<!-- 尝试屏蔽被嵌入的非页面元素,包括JavaScript-->
<iframe sandbox='' style='display:none;' >
 <!-- 
</body>
</html>
